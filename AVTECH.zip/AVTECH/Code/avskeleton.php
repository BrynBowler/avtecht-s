<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>Chat</title>
    
    <link rel="stylesheet" href="avtechstyle.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>

    <script type="text/javascript" src="menufunctionality.js"></script>

</head>
<body> <!-- onLoad="priorityStyle()" -->


    <?php
        
        /*$con =  mysqli_connect('localhost:3308','root','');

        if(!$con)
        {
            echo 'Not Connected To Server';
        }

        if(!mysqli_select_db($con, 'avtechts'))
        {
            echo 'Database Not Selected';
        }*/

        $host = 'localhost:3308';
        $user = 'root';
        $pass = '';
        $db = 'avtechts';

        $mysqli = new mysqli($host,$user,$pass,$db);

        $result = $mysqli->query
            ("SELECT * FROM avtechts ORDER BY creationDate DESC")
        or die($mysqli->error);

        $resultMM = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'MondayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultMMD = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'MondayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultME = $mysqli->query 
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'MondayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultMN = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'MondayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);
        
        $resultTM = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'TuesdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTMD = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'TuesdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTE = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'TuesdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTN = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'TuesdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWM = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'WednesdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWMD = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'WednesdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWE = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'WednesdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWN = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'WednesdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHM = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'ThursdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHMD = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'ThursdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHE = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'ThursdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHN = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'ThursdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFM = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'FridayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFMD = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'FridayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFE = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'FridayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFN = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'FridayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultCompletedJobs = $mysqli->query
            ("SELECT * FROM completedjobs ORDER BY completedDate DESC")
        or die($mysqli->error);

        $jobSwaps = $mysqli->query
            ("SELECT * FROM jobSwaps ORDER BY jobDate DESC")
        or die($mysqli->error);
    ?>

    <div class="top-section">
        <div id="banner">
            <h1>AvTech Timetabling and Scheduling Program</h1>
            <div id="signOut">
                <a href="avtechtslogin.php"><h1>Sign Out</h1></a>
            </div>
        </div>

        <div id="menu">
            <div id="menu-item-PT" style="border-left: solid;">
                <a href=""><h2>Personal Timetable</h2></a>
            </div>
            <div id="menu-item-JD">
                <a href=""><h2>Job Dashboard</h2></a>
            </div>
            <!--<div id="menu-item-JS">
                <a href=""><h2>Availible Swaps</h2></a>
            </div>-->
            <div id="menu-item-JI">
                <a href=""><h2>Completed Jobs</h2></a>
            </div>
        </div>
    </div>

    <div id="personalTimetable">
        <div id="Timetable">
            <style type="text/css">
                .tg  {border-collapse:collapse;border-spacing:0;border-color:#aaa; width: 100%}
                .tg td{font-family: monospace;, sans-serif;font-size:1.5vw;padding:10px 5px;border-style:solid;overflow:hidden;word-break:normal;border-color:#aaa;color:#333;background-color:#fff;}
                .tg th{font-family: monospace;, sans-serif;font-size:1.5vw;font-weight:normal;padding:10px 5px;border-style:solid;overflow:hidden;word-break:normal;border-color:#aaa;color:#fff;background-color:#f38630;}
                .tg .tg-zped{background-color:#f38630;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-nb35{font-style:italic;background-color:#343434;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-nl2w{background-color:#9b9b9b;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-0lax{text-align:center;vertical-align:top;width:22%}
            </style>

            <table class="tg">
                <tr>
                    <th class="tg-nb35"></th>
                    <th class="tg-zped">Morning</th>
                    <th class="tg-zped">Afternoon</th>
                    <th class="tg-zped">Evening</th>
                    <th class="tg-zped">Night</th>
                </tr>
                <tr>
                    <td class="tg-nl2w">Monday</td>
                    <td class="tg-0lax" id="mondayMorning">
                        <?php while ( $avtechts = $resultMM->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                    <div class="serviceBoxStyle">
                                        <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                    </div>
                                    <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                    <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                    <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                    <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                    
                                    <h2 id="sI" class="sIStyle">Service Information:</h2>
                                    <div class="serviceBox2Style">
                                        <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                    </div>
                                    <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayMidday">
                        <?php while ( $avtechts = $resultMMD->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayEvening">
                        <?php while ( $avtechts = $resultME->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayNight">
                        <?php while ( $avtechts = $resultMN->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Tuesday</td>
                    <td class="tg-0lax" id="tuesdayMorning">
                        <?php while ( $avtechts = $resultTM->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayMidday">
                        <?php while ( $avtechts = $resultTMD->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayEvening">
                        <?php while ( $avtechts = $resultTE->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayNight">
                        <?php while ( $avtechts = $resultTN->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Wednesday</td>
                    <td class="tg-0lax" id="wednesdayMorning">
                        <?php while ( $avtechts = $resultWM->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayMidday">
                        <?php while ( $avtechts = $resultWMD->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayEvening">
                        <?php while ( $avtechts = $resultWE->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayNight">
                        <?php while ( $avtechts = $resultWN->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Thursday</td>
                    <td class="tg-0lax" id="thursdayMorning">
                        <?php while ( $avtechts = $resultTHM->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayMidday">
                        <?php while ( $avtechts = $resultTHMD->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayEvening">
                        <?php while ( $avtechts = $resultTHE->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayNight">
                        <?php while ( $avtechts = $resultTHN->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Friday</td>
                    <td class="tg-0lax" id="fridayMorning">
                        <?php while ( $avtechts = $resultFM->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayMidday">
                        <?php while ( $avtechts = $resultFMD->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayEvening">
                        <?php while ( $avtechts = $resultFE->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayNight">
                        <?php while ( $avtechts = $resultFN->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                <form id="swapJob" action="jobSwap1.php" method="post">              
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                        <input id="timetableSlot" name="timetableSlot" type="hidden" value=<?= $avtechts['timetableSlot']?>>
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Request Swap">
                                </form>

                                <form id="completeJobForm" action="completeJob1.php" method="post">
                                    <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                    <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                    <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                    <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                    <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                    <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                    <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                    <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                    <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                    <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                    <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                    
                                    <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                                    <input id="completeJob" class="button_text" type="submit" name="submit" value="Complete Job" style="margin: 2%;">
                                </form>
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div id="jobDashboard">
        <h2>Job Dashboard</h2>
        <div id="jobDashboardContent">
        
        <?php

        while ( $avtechts = $result->fetch_assoc()):?>
            <div id="dashboardJob" class="dashboardJobStyle">
                <div class="serviceBoxStyle">
                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                </div>
                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                <h2 id="dateCreated" class="dateCreatedStyle">Date created:<?= $avtechts['creationDate']?></h2>
                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                
                <h2 id="sI" class="sIStyle">Service Information:</h2>
                <div class="serviceBox2Style">
                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                </div>
                    <h2 class="sIStyle">Select a TimetableSlot</h2>
                <form id="acceptJobInsert" display="hidden" action="acceptJob1.php" method="post">
                    <select id="assignDateInsert" name="assignDateInsert"">
                        <option value="mondayMorning">Monday Morning</option>
                        <option value="mondayMidday">Monday Midday</option>
                        <option value="mondayEvening">Monday Evening</option>
                        <option value="mondayNight">Monday Night</option>
                        <option value="tuesdayMorning">Tuesday Morning</option>
                        <option value="tuesdayMidday">Tuesday Midday</option>
                        <option value="tuesdayEvening">Tuesday Evening</option>
                        <option value="tuesdayNight">Tuesday Night</option>
                        <option value="wednesdayMorning">Wednesday Morning</option>
                        <option value="wednesdayMidday">Wednesday Midday</option>
                        <option value="wednesdayEvening">Wednesday Evening</option>
                        <option value="wednesdayNight">Wednesday Night</option>
                        <option value="thursdayMorning">Thursday Morning</option>
                        <option value="thursdayMidday">Thursday Midday</option>
                        <option value="thursdayEvening">Thursday Evening</option>
                        <option value="thursdayNight">Thursday Night</option>
                        <option value="fridayMorning">Friday Morning</option>
                        <option value="fridayMidday">Friday Midday</option>
                        <option value="fridayEvening">Friday Evening</option>
                        <option value="fridayNight">Friday Night</option>
                    </select>
                <div class="buttonDivStyle">
                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                        
                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">

                        <input id="sendInsert" class="button_text" type="submit" name="submit" value="Accept Job">
                    </form>
                </div>
            </div>
        <?php endwhile;?>
            <div class="listEnd">
                <h2 class="listEndText">End of Tickets</h2>
            </div>
        </div>
    </div>

    <script>
        //if priority = green{set ticket header to green}
    </script>

    <div id="jobSwaps">
    <h2>Availible Swaps</h2>
        <?php
            while ( $avtechts = $jobSwaps->fetch_assoc()):?>
                <div id="completedJobsStyle" class="dashboardJobStyle">
                    <div class="serviceBoxStyle">
                        <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                    </div>
                    <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                    <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                    <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                    <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                    
                    <h2 id="sI" class="sIStyle">Service Information:</h2>
                    <div class="serviceBox2Style">
                        <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                    </div>
                    <div>
                    <h2 id="previousTime" class="dateCompletedStyle">Swap From: <?= $avtechts['timetableSlot']?></h2>
                    </div>
                    <form id="requestJob" action="acceptSwap1.php" method="post">
                                    <select id="jobSwapInsert" name="jobSwapInsert">
                                        <option value="mondayMorning">Monday Morning</option>
                                        <option value="mondayMidday">Monday Midday</option>
                                        <option value="mondayEvening">Monday Evening</option>
                                        <option value="mondayNight">Monday Night</option>
                                        <option value="tuesdayMorning">Tuesday Morning</option>
                                        <option value="tuesdayMidday">Tuesday Midday</option>
                                        <option value="tuesdayEvening">Tuesday Evening</option>
                                        <option value="tuesdayNight">Tuesday Night</option>
                                        <option value="wednesdayMorning">Wednesday Morning</option>
                                        <option value="wednesdayMidday">Wednesday Midday</option>
                                        <option value="wednesdayEvening">Wednesday Evening</option>
                                        <option value="wednesdayNight">Wednesday Night</option>
                                        <option value="thursdayMorning">Thursday Morning</option>
                                        <option value="thursdayMidday">Thursday Midday</option>
                                        <option value="thursdayEvening">Thursday Evening</option>
                                        <option value="thursdayNight">Thursday Night</option>
                                        <option value="fridayMorning">Friday Morning</option>
                                        <option value="fridayMidday">Friday Midday</option>
                                        <option value="fridayEvening">Friday Evening</option>
                                        <option value="fridayNight">Friday Night</option>
                                    </select>
                                    
                                        <input id="jobNumberInsert" name="jobNumberInsert" type="hidden" value="<?= $avtechts['jobNumber']?>">
                                        <input id="siteNameInsert" name="siteNameInsert" type="hidden" value="<?= $avtechts['siteName']?>">
                                        <input id="firstNameInsert" name="firstNameInsert" type="hidden" value="<?= $avtechts['firstName']?>">
                                        <input id="lastNameInsert" name="lastNameInsert" type="hidden" value="<?= $avtechts['lastName']?>">
                                        <input id="phoneNoInsert" name="phoneNoInsert" type="hidden" value="<?= $avtechts['phoneNumber']?>">
                                        <input id="streetAddressInsert" name="streetAddressInsert" type="hidden" value="<?= $avtechts['streetAddress']?>">
                                        <input id="linetwoAddressInsert" name="linetwoAddressInsert" type="hidden" value="<?= $avtechts['linetwoAddress']?>">
                                        <input id="cityInsert" name="cityInsert" type="hidden" value="<?= $avtechts['city']?>">
                                        <input id="countyInsert" name="countyInsert" type="hidden" value="<?= $avtechts['county']?>">
                                        <input id="postcodeInsert" name="postcodeInsert" type="hidden" value="<?= $avtechts['postcode']?>">
                                        <input id="serviceInfoInsert" name="serviceInfoInsert" type="hidden" value="<?= $avtechts['serviceInfo']?>">
                                        
                                        <input id="priorityInsert" name="priorityInsert" type="hidden" value="<?= $avtechts['priority']?>">
                                    
                                    <input id="requestSwap" class="button_text" type="submit" name="submit" value="Accept Swap">
                                </form>
                </div>
            <?php endwhile;?>
                <div class="listEnd">
                    <h2 class="listEndText">End of Availible Swaps</h2>
                </div>
            </div>
        </div>
    </div>

    <div id="completedJobs">
    <h2>Completed Jobs</h2>
        <?php
            while ( $avtechts = $resultCompletedJobs->fetch_assoc()):?>
                <div id="completedJobsStyle" class="dashboardJobStyle">
                    <div class="serviceBoxStyle">
                        <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                    </div>
                    <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                    <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                    <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                    <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                    
                    <h2 id="sI" class="sIStyle">Service Information:</h2>
                    <div class="serviceBox2Style">
                        <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                    </div>
                    <h2 id="dateCompleted" class="dateCompletedStyle">Date Completed: <?= $avtechts['completedDate']?></h2>
                </div>
            <?php endwhile;?>
                <div class="listEnd">
                    <h2 class="listEndText">End of Completed Tickets</h2>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        document.getElementById("menu-item-PT").onclick = function() {
            document.getElementById("personalTimetable").style.display = "block";
            document.getElementById("jobDashboard").style.display = "none";
            document.getElementById("completedJobs").style.display = "none";
            document.getElementById("jobSwaps").style.display = "none";
            event.preventDefault();
        }

        document.getElementById("menu-item-JD").onclick = function() {
            document.getElementById("jobDashboard").style.display = "block";
            document.getElementById("personalTimetable").style.display = "none";
            document.getElementById("completedJobs").style.display = "none";
            document.getElementById("jobSwaps").style.display = "none";
            event.preventDefault();
        }

        document.getElementById("menu-item-JI").onclick = function() {
            document.getElementById("completedJobs").style.display = "block";
            document.getElementById("jobDashboard").style.display = "none";
            document.getElementById("personalTimetable").style.display = "none";
            document.getElementById("jobSwaps").style.display = "none";
            event.preventDefault();
        }

        document.getElementById("menu-item-JS").onclick = function() {
            document.getElementById("jobSwaps").style.display = "block";
            document.getElementById("completedJobs").style.display = "none";
            document.getElementById("jobDashboard").style.display = "none";
            document.getElementById("personalTimetable").style.display = "none";
            event.preventDefault();
        }
        </script>
</body>