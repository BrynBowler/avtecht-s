<?php

    $con =  mysqli_connect('localhost:3308','root','');

    if(!$con)
    {
        echo 'Not Connected To Server';
    }

    if(!mysqli_select_db($con, 'avtechts'))
    {
        echo 'Database Not Selected';
    }

    $jobNumber = $_POST['jobNumber'];
    $siteName = $_POST['siteName'];
    $phoneNumber = $_POST['phoneNumber'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $streetAddress = $_POST['streetAddress'];
    $linetwoAddress = $_POST['linetwoAddress'];
    $city = $_POST['city'];
    $county = $_POST['county'];
    $postcode = $_POST['postcode'];
    $serviceInfo = $_POST['serviceInfo'];
    $priority_value = $_POST['priority'];

    $sql = "INSERT INTO avtechts (jobNumber,siteName,phoneNumber,firstName,lastName,streetAddress,linetwoAddress,city,county,postcode,serviceInfo,priority) 
            VALUES ('$jobNumber','$siteName','$phoneNumber','$firstName','$lastName','$streetAddress','$linetwoAddress','$city','$county','$postcode','$serviceInfo','$priority_value')";

    if(!mysqli_query($con,$sql))
    {
        echo 'Not Inserted';
    }
    else
    {
        echo 'Inserted';
    }

    header("refresh:2 url=avtechtse2.php");

?>