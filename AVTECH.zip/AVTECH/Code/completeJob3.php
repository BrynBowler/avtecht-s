<?php

    $con =  mysqli_connect('localhost:3308','root','');

    if(!$con)
    {
        echo 'Not Connected To Server';
    }

    if(!mysqli_select_db($con, 'avtechts'))
    {
        echo 'Database Not Selected';
    }

    $jobNumber = $_POST['jobNumberInsert'];
    $siteName = $_POST['siteNameInsert'];
    $phoneNumber = $_POST['phoneNoInsert'];
    $firstName = $_POST['firstNameInsert'];
    $lastName = $_POST['lastNameInsert'];
    $streetAddress = $_POST['streetAddressInsert'];
    $linetwoAddress = $_POST['linetwoAddressInsert'];
    $city = $_POST['cityInsert'];
    $county = $_POST['countyInsert'];
    $postcode = $_POST['postcodeInsert'];
    $serviceInfo = $_POST['serviceInfoInsert'];
    $jobDate = $_POST['jobDateInsert'];
    $priority_value = $_POST['priorityInsert'];

    $sql = "INSERT INTO completedJobs (jobNumber,siteName,phoneNumber,firstName,lastName,streetAddress,linetwoAddress,city,county,postcode,serviceInfo,priority) 
            VALUES ('$jobNumber','$siteName','$phoneNumber','$firstName','$lastName','$streetAddress','$linetwoAddress','$city','$county','$postcode','$serviceInfo','$priority_value');";

    $sql .= "DELETE FROM e3timetable WHERE jobNumber= $jobNumber";

    if(!mysqli_multi_query($con,$sql))
    {
        echo 'Not Inserted or Deleted';
    }
    else
    {
        echo 'Inserted and Deleted';
    }

    header("refresh:2 url=avtechtse3.php");
?>