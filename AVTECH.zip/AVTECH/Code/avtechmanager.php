<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>Chat</title>
    
    <link rel="stylesheet" href="avtechstyle.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>

    <script type="text/javascript" src="menufunctionality.js"></script>

</head>
<body> <!-- onLoad="priorityStyle()" -->


    <?php
        
        session_start();

        if(!isset($_SESSION['Garry']))
        {
            header('location: avtechtslogin.php');
        }
        
        /*$con =  mysqli_connect('localhost:3308','root','');

        if(!$con)
        {
            echo 'Not Connected To Server';
        }

        if(!mysqli_select_db($con, 'avtechts'))
        {
            echo 'Database Not Selected';
        }*/

        $host = 'localhost:3308';
        $user = 'root';
        $pass = '';
        $db = 'avtechts';

        $mysqli = new mysqli($host,$user,$pass,$db);

        $result = $mysqli->query
            ("SELECT * FROM avtechts ORDER BY creationDate DESC")
        or die($mysqli->error);

        $resultMM = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'MondayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultMMD = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'MondayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultME = $mysqli->query 
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'MondayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultMN = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'MondayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);
        
        $resultTM = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'TuesdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTMD = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'TuesdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTE = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'TuesdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTN = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'TuesdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWM = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'WednesdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWMD = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'WednesdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWE = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'WednesdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWN = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'WednesdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHM = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'ThursdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHMD = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'ThursdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHE = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'ThursdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHN = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'ThursdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFM = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'FridayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFMD = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'FridayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFE = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'FridayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFN = $mysqli->query
            ("SELECT * FROM e1timetable WHERE timetableSlot = 'FridayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        //---------------------------------------------------------------------

        $resultMM2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'MondayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultMMD2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'MondayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultME2 = $mysqli->query 
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'MondayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultMN2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'MondayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);
        
        $resultTM2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'TuesdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTMD2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'TuesdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTE2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'TuesdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTN2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'TuesdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWM2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'WednesdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWMD2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'WednesdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWE2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'WednesdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWN2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'WednesdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHM2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'ThursdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHMD2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'ThursdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHE2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'ThursdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHN2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'ThursdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFM2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'FridayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFMD2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'FridayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFE2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'FridayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFN2 = $mysqli->query
            ("SELECT * FROM e2timetable WHERE timetableSlot = 'FridayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        //---------------------------------------------------------------------

        $resultMM3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'MondayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultMMD3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'MondayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultME3 = $mysqli->query 
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'MondayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultMN3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'MondayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);
        
        $resultTM3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'TuesdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTMD3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'TuesdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTE3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'TuesdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTN3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'TuesdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWM3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'WednesdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWMD3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'WednesdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWE3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'WednesdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultWN3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'WednesdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHM3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'ThursdayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHMD3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'ThursdayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHE3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'ThursdayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultTHN3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'ThursdayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFM3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'FridayMorning' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFMD3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'FridayMidday' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFE3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'FridayEvening' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultFN3 = $mysqli->query
            ("SELECT * FROM e3timetable WHERE timetableSlot = 'FridayNight' ORDER BY jobDate DESC")
        or die($mysqli->error);

        $resultCompletedJobs = $mysqli->query
            ("SELECT * FROM completedjobs ORDER BY completedDate DESC")
        or die($mysqli->error);

        $jobSwaps = $mysqli->query
            ("SELECT * FROM jobSwaps ORDER BY jobDate DESC")
        or die($mysqli->error);
    ?>

    <div class="top-section">
        <div id="banner">
            <h1>AvTech Timetabling and Scheduling Program</h1>
            <div id="signOut">
                <a href="avtechtslogin.php"><h1>Sign Out</h1></a>
            </div>
        </div>

        <div id="menu">
            <div id="menu-item-PT" style="border-left: solid;">
                <a href=""><h2>Personal Timetable</h2></a>
            </div>
            <div id="menu-item-JD">
                <a href=""><h2>Job Dashboard</h2></a>
            </div>
            <div id="menu-item-JS">
                <a href=""><h2>Availible Swaps</h2></a>
            </div>
            <div id="menu-item-JI">
                <a href=""><h2>Completed Jobs</h2></a>
            </div>
        </div>
    </div>

    <div id="personalTimetable">
    <div id="Timetable" style="border: solid;
                                    padding: 20px;
                                    background-color: #90EE90;">
            <h2 style="color: black">Brad Timetable</h2>
            <style type="text/css">
                .tg  {border-collapse:collapse;border-spacing:0;border-color:#aaa; width: 100%}
                .tg td{font-family: monospace;, sans-serif;font-size:1.5vw;padding:10px 5px;border-style:solid;overflow:hidden;word-break:normal;border-color:#aaa;color:#333;background-color:#fff;}
                .tg th{font-family: monospace;, sans-serif;font-size:1.5vw;font-weight:normal;padding:10px 5px;border-style:solid;overflow:hidden;word-break:normal;border-color:#aaa;color:#fff;background-color:#f38630;}
                .tg .tg-zped{background-color:#f38630;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-nb35{font-style:italic;background-color:#343434;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-nl2w{background-color:#9b9b9b;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-0lax{text-align:center;vertical-align:top;width:22%}
            </style>

            <table class="tg">
                <tr>
                    <th class="tg-nb35"></th>
                    <th class="tg-zped">Morning</th>
                    <th class="tg-zped">Afternoon</th>
                    <th class="tg-zped">Evening</th>
                    <th class="tg-zped">Night</th>
                </tr>
                <tr>
                    <td class="tg-nl2w">Monday</td>
                    <td class="tg-0lax" id="mondayMorning">
                        <?php while ( $avtechts = $resultMM->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                    <div class="serviceBoxStyle">
                                        <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                    </div>
                                    <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                    <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                    <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                    <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                    
                                    <h2 id="sI" class="sIStyle">Service Information:</h2>
                                    <div class="serviceBox2Style">
                                        <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                    </div>
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayMidday">
                        <?php while ( $avtechts = $resultMMD->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>

                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayEvening">
                        <?php while ( $avtechts = $resultME->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayNight">
                        <?php while ( $avtechts = $resultMN->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Tuesday</td>
                    <td class="tg-0lax" id="tuesdayMorning">
                        <?php while ( $avtechts = $resultTM->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayMidday">
                        <?php while ( $avtechts = $resultTMD->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayEvening">
                        <?php while ( $avtechts = $resultTE->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayNight">
                        <?php while ( $avtechts = $resultTN->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Wednesday</td>
                    <td class="tg-0lax" id="wednesdayMorning">
                        <?php while ( $avtechts = $resultWM->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayMidday">
                        <?php while ( $avtechts = $resultWMD->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayEvening">
                        <?php while ( $avtechts = $resultWE->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayNight">
                        <?php while ( $avtechts = $resultWN->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Thursday</td>
                    <td class="tg-0lax" id="thursdayMorning">
                        <?php while ( $avtechts = $resultTHM->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayMidday">
                        <?php while ( $avtechts = $resultTHMD->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayEvening">
                        <?php while ( $avtechts = $resultTHE->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayNight">
                        <?php while ( $avtechts = $resultTHN->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Friday</td>
                    <td class="tg-0lax" id="fridayMorning">
                        <?php while ( $avtechts = $resultFM->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayMidday">
                        <?php while ( $avtechts = $resultFMD->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayEvening">
                        <?php while ( $avtechts = $resultFE->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayNight">
                        <?php while ( $avtechts = $resultFN->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
            </table>
        </div>

        <!--------------------------------------------->

        <div id="Timetable" style="border: solid;
                                    padding: 20px;
                                    background-color: #87CEFA;">
            <h2 style="color: black">Dan Timetable</h2>
            <style type="text/css">
                .tg  {border-collapse:collapse;border-spacing:0;border-color:#aaa; width: 100%}
                .tg td{font-family: monospace;, sans-serif;font-size:1.5vw;padding:10px 5px;border-style:solid;overflow:hidden;word-break:normal;border-color:#aaa;color:#333;background-color:#fff;}
                .tg th{font-family: monospace;, sans-serif;font-size:1.5vw;font-weight:normal;padding:10px 5px;border-style:solid;overflow:hidden;word-break:normal;border-color:#aaa;color:#fff;background-color:#f38630;}
                .tg .tg-zped{background-color:#f38630;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-nb35{font-style:italic;background-color:#343434;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-nl2w{background-color:#9b9b9b;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-0lax{text-align:center;vertical-align:top;width:22%}
            </style>

            <table class="tg">
                <tr>
                    <th class="tg-nb35"></th>
                    <th class="tg-zped">Morning</th>
                    <th class="tg-zped">Afternoon</th>
                    <th class="tg-zped">Evening</th>
                    <th class="tg-zped">Night</th>
                </tr>
                <tr>
                    <td class="tg-nl2w">Monday</td>
                    <td class="tg-0lax" id="mondayMorning">
                        <?php while ( $avtechts = $resultMM2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                    <div class="serviceBoxStyle">
                                        <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                    </div>
                                    <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                    <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                    <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                    <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                    
                                    <h2 id="sI" class="sIStyle">Service Information:</h2>
                                    <div class="serviceBox2Style">
                                        <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                    </div>
                                    
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayMidday">
                        <?php while ( $avtechts = $resultMMD2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayEvening">
                        <?php while ( $avtechts = $resultME2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayNight">
                        <?php while ( $avtechts = $resultMN2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Tuesday</td>
                    <td class="tg-0lax" id="tuesdayMorning">
                        <?php while ( $avtechts = $resultTM2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayMidday">
                        <?php while ( $avtechts = $resultTMD2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayEvening">
                        <?php while ( $avtechts = $resultTE2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayNight">
                        <?php while ( $avtechts = $resultTN2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Wednesday</td>
                    <td class="tg-0lax" id="wednesdayMorning">
                        <?php while ( $avtechts = $resultWM2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayMidday">
                        <?php while ( $avtechts = $resultWMD2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayEvening">
                        <?php while ( $avtechts = $resultWE2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayNight">
                        <?php while ( $avtechts = $resultWN2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Thursday</td>
                    <td class="tg-0lax" id="thursdayMorning">
                        <?php while ( $avtechts = $resultTHM2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayMidday">
                        <?php while ( $avtechts = $resultTHMD2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayEvening">
                        <?php while ( $avtechts = $resultTHE2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayNight">
                        <?php while ( $avtechts = $resultTHN2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Friday</td>
                    <td class="tg-0lax" id="fridayMorning">
                        <?php while ( $avtechts = $resultFM2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayMidday">
                        <?php while ( $avtechts = $resultFMD2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                               
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayEvening">
                        <?php while ( $avtechts = $resultFE2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayNight">
                        <?php while ( $avtechts = $resultFN2->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
            </table>
        </div>

        <!---------------------------------->

        <div id="Timetable" style="border: solid;
                                    padding: 20px;
                                    background-color: #F08080;">
            <h2 style="color: black">Neil Timetable</h2>
            <style type="text/css">
                .tg  {border-collapse:collapse;border-spacing:0;border-color:#aaa; width: 100%}
                .tg td{font-family: monospace;, sans-serif;font-size:1.5vw;padding:10px 5px;border-style:solid;overflow:hidden;word-break:normal;border-color:#aaa;color:#333;background-color:#fff;}
                .tg th{font-family: monospace;, sans-serif;font-size:1.5vw;font-weight:normal;padding:10px 5px;border-style:solid;overflow:hidden;word-break:normal;border-color:#aaa;color:#fff;background-color:#f38630;}
                .tg .tg-zped{background-color:#f38630;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-nb35{font-style:italic;background-color:#343434;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-nl2w{background-color:#9b9b9b;color:#000000;border-color:#000000;text-align:center;vertical-align:top}
                .tg .tg-0lax{text-align:center;vertical-align:top;width:22%}
            </style>

            <table class="tg">
                <tr>
                    <th class="tg-nb35"></th>
                    <th class="tg-zped">Morning</th>
                    <th class="tg-zped">Afternoon</th>
                    <th class="tg-zped">Evening</th>
                    <th class="tg-zped">Night</th>
                </tr>
                <tr>
                    <td class="tg-nl2w">Monday</td>
                    <td class="tg-0lax" id="mondayMorning">
                        <?php while ( $avtechts = $resultMM3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                    <div class="serviceBoxStyle">
                                        <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                    </div>
                                    <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                    <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                    <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                    <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                    
                                    <h2 id="sI" class="sIStyle">Service Information:</h2>
                                    <div class="serviceBox2Style">
                                        <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                    </div>
                                    
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayMidday">
                        <?php while ( $avtechts = $resultMMD3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayEvening">
                        <?php while ( $avtechts = $resultME3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="mondayNight">
                        <?php while ( $avtechts = $resultMN3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Tuesday</td>
                    <td class="tg-0lax" id="tuesdayMorning">
                        <?php while ( $avtechts = $resultTM3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayMidday">
                        <?php while ( $avtechts = $resultTMD3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayEvening">
                        <?php while ( $avtechts = $resultTE3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="tuesdayNight">
                        <?php while ( $avtechts = $resultTN3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Wednesday</td>
                    <td class="tg-0lax" id="wednesdayMorning">
                        <?php while ( $avtechts = $resultWM3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayMidday">
                        <?php while ( $avtechts = $resultWMD3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayEvening">
                        <?php while ( $avtechts = $resultWE3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="wednesdayNight">
                        <?php while ( $avtechts = $resultWN3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Thursday</td>
                    <td class="tg-0lax" id="thursdayMorning">
                        <?php while ( $avtechts = $resultTHM3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayMidday">
                        <?php while ( $avtechts = $resultTHMD3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayEvening">
                        <?php while ( $avtechts = $resultTHE3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="thursdayNight">
                        <?php while ( $avtechts = $resultTHN3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
                <tr>
                    <td class="tg-nl2w">Friday</td>
                    <td class="tg-0lax" id="fridayMorning">
                        <?php while ( $avtechts = $resultFM3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                               
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayMidday">
                        <?php while ( $avtechts = $resultFMD3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayEvening">
                        <?php while ( $avtechts = $resultFE3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                    <td class="tg-0lax" id="fridayNight">
                        <?php while ( $avtechts = $resultFN3->fetch_assoc()):?>
                            <div id="timetableJob" class="timetableJobStyle">
                                <div class="serviceBoxStyle">
                                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                                </div>
                                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                                
                                <h2 id="sI" class="sIStyle">Service Information:</h2>
                                <div class="serviceBox2Style">
                                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                                </div>
                                
                            </div>
                        <?php endwhile;?>
                    </td>
                </tr>
            </table>
        </div>
    </div>

    <div id="jobDashboard">
        <h2>Job Dashboard</h2>
        <div id="jobDashboardContent">
        
        <?php

        while ( $avtechts = $result->fetch_assoc()):?>
            <div id="dashboardJob" class="dashboardJobStyle">
                <div class="serviceBoxStyle">
                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                </div>
                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                <h2 id="dateCreated" class="dateCreatedStyle">Date created:<?= $avtechts['creationDate']?></h2>
                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                
                <h2 id="sI" class="sIStyle">Service Information:</h2>
                <div class="serviceBox2Style">
                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                </div>
                </div>
            </div>
        <?php endwhile;?>
            <div class="listEnd">
                <h2 class="listEndText">End of Tickets</h2>
            </div>
        </div>
    </div>

    <script>
        //if priority = green{set ticket header to green}
    </script>

    <div id="jobSwaps">
    <h2>Availible Swaps</h2>
        <?php
            while ( $avtechts = $jobSwaps->fetch_assoc()):?>
                <div id="completedJobsStyle" class="dashboardJobStyle">
                    <div class="serviceBoxStyle">
                        <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                    </div>
                    <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                    <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                    <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                    <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                    
                    <h2 id="sI" class="sIStyle">Service Information:</h2>
                    <div class="serviceBox2Style">
                        <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                    </div>
                    <div>
                    <h2 id="previousTime" class="dateCompletedStyle">Swap From: <?= $avtechts['timetableSlot']?></h2>
                    </div>
                    
                </div>
            <?php endwhile;?>
                <div class="listEnd">
                    <h2 class="listEndText">End of Availible Swaps</h2>
                </div>
            </div>
        </div>
    </div>

    <div id="completedJobs">
    <h2>Completed Jobs</h2>
        <?php
            while ( $avtechts = $resultCompletedJobs->fetch_assoc()):?>
                <div id="completedJobsStyle" class="dashboardJobStyle">
                    <div class="serviceBoxStyle">
                        <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                    </div>
                    <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                    <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                    <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                    <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                    
                    <h2 id="sI" class="sIStyle">Service Information:</h2>
                    <div class="serviceBox2Style">
                        <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                    </div>
                    <h2 id="dateCompleted" class="dateCompletedStyle">Date Completed: <?= $avtechts['completedDate']?></h2>
                </div>
            <?php endwhile;?>
                <div class="listEnd">
                    <h2 class="listEndText">End of Completed Tickets</h2>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        document.getElementById("menu-item-PT").onclick = function() {
            document.getElementById("personalTimetable").style.display = "block";
            document.getElementById("jobDashboard").style.display = "none";
            document.getElementById("completedJobs").style.display = "none";
            document.getElementById("jobSwaps").style.display = "none";
            event.preventDefault();
        }

        document.getElementById("menu-item-JD").onclick = function() {
            document.getElementById("jobDashboard").style.display = "block";
            document.getElementById("personalTimetable").style.display = "none";
            document.getElementById("completedJobs").style.display = "none";
            document.getElementById("jobSwaps").style.display = "none";
            event.preventDefault();
        }

        document.getElementById("menu-item-JI").onclick = function() {
            document.getElementById("completedJobs").style.display = "block";
            document.getElementById("jobDashboard").style.display = "none";
            document.getElementById("personalTimetable").style.display = "none";
            document.getElementById("jobSwaps").style.display = "none";
            event.preventDefault();
        }

        document.getElementById("menu-item-JS").onclick = function() {
            document.getElementById("jobSwaps").style.display = "block";
            document.getElementById("completedJobs").style.display = "none";
            document.getElementById("jobDashboard").style.display = "none";
            document.getElementById("personalTimetable").style.display = "none";
            event.preventDefault();
        }
        </script>
</body>