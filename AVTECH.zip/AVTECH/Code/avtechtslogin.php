<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>Chat</title>
    
    <link rel="stylesheet" href="avtechtsloginstyle.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>

</head>
<body>
    <?php 

        if(isset($_REQUEST['attempt']))
        {
            $username = $_POST['username'];
            $password = $_POST['password'];
        }

    ?>


    <div id="loginDiv">
        <h2>AVTech Login</h2>
            <div id="loginformDiv">
                <form id="login" method="post" action="login.php?attempt">
                    <div id="username">
                        <h4>Username:</h4>
                            <input type="text" id="usernameBox" name="username" placeholder="Enter Username">
                    </div>
                    <div id="password">
                        <h4>Password:</h4>
                            <input type="password" id="passwordBox" name="password" placeholder="Enter Password">
                    </div>   
                </div>
            <div id="loginSubmit">
                <input type="submit" value="Submit">
            </div>
        </form>
    </div>
</body>