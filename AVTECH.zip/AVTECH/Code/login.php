<?php 

if(isset($_REQUEST['attempt'])){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $con =  mysqli_connect('localhost:3308','root','');

    if(!$con)
    {
        echo 'Not Connected To Server';
    }

    if(!mysqli_select_db($con, 'avtechts'))
    {
        echo 'Database Not Selected';
    }

    $query = mysqli_query($con, "SELECT username FROM users WHERE username = '$username' AND password = '$password'")
                    or die(mysql_error());
    
    $total = mysqli_num_rows($query);

    if ($total > 0 && $username == 'Brad')
    {
        session_start();
        $_SESSION['Brad'] = $username;
        header('location: avtechtse1.php');
    }
    else if($total > 0 && $username == 'Dan')
    {
        session_start();
        $_SESSION['Dan'] = $username;
        header('location: avtechtse2.php');
    }
    else if($total > 0 && $username == 'Neil')
    {
        session_start();
        $_SESSION['Neil'] = $username;
        header('location: avtechtse3.php');
    }
    else if($total > 0 && $username == 'Cheryl')
    {
        session_start();
        $_SESSION['Cheryl'] = $username;
        header('location: avtechreceptionist.php');
    }
    else if($total > 0 && $username == 'Garry')
    {
        session_start();
        $_SESSION['Garry'] = $username;
        header('location: avtechmanager.php');
    }
    else
    {
        header('location: avtechtslogin.php');
    }
}
    
?>