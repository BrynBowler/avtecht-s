<?php

    $con =  mysqli_connect('localhost:3308','root','');

    if(!$con)
    {
        echo 'Not Connected To Server';
    }

    if(!mysqli_select_db($con, 'avtechts'))
    {
        echo 'Database Not Selected';
    }

    $sql = "DELETE FROM avtechts WHERE jobNumber='$_GET[id]'";

    if(!mysqli_query($con,$sql))
    {
        echo 'Not Deleted';
    }
    else
    {
        echo 'Deleted';
    }

    header("refresh:2 url=avtechtse1.php");
?>