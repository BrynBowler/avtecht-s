<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <title>Chat</title>
    
    <link rel="stylesheet" href="avtechstyle.css" type="text/css" />
    
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>

    <script type="text/javascript" src="menufunctionality.js"></script>

</head>
<body> <!-- onLoad="priorityStyle()" -->


    <?php
        
        session_start();

        if(!isset($_SESSION['Cheryl']))
        {
            header('location: avtechtslogin.php');
        }
        
        /*$con =  mysqli_connect('localhost:3308','root','');

        if(!$con)
        {
            echo 'Not Connected To Server';
        }

        if(!mysqli_select_db($con, 'avtechts'))
        {
            echo 'Database Not Selected';
        }*/

        $host = 'localhost:3308';
        $user = 'root';
        $pass = '';
        $db = 'avtechts';

        $mysqli = new mysqli($host,$user,$pass,$db);

        $result = $mysqli->query
            ("SELECT * FROM avtechts ORDER BY creationDate DESC")
        or die($mysqli->error);

        //TESTING
        //print_r($result);die;

        /*$result = $mysqli->query
            ("SELECT * FROM avtechts WHERE jobNumber = '999'")
        or die($mysqli->error);*/

        //print_r($result);die;

        $resultCompletedJobs = $mysqli->query
            ("SELECT * FROM completedjobs ORDER BY completedDate DESC")
        or die($mysqli->error);

        $jobSwaps = $mysqli->query
            ("SELECT * FROM jobSwaps ORDER BY jobDate DESC")
        or die($mysqli->error);
    ?>


    <!-- TESTING -->
    <div>
    <?php
        //print_r($result->fetch_assoc());
        //print_r($result->fetch_assoc()); die;
    ?>           
    </div>



    <div class="top-section">
        <div id="banner">
            <h1>AvTech Timetabling and Scheduling Program</h1>
            <div id="signOut">
                <a href="avtechtslogin.php"><h1>Sign Out</h1></a>
            </div>
        </div>

        <div id="menu">
            <div id="menu-item-JD">
                <a href=""><h2>Job Dashboard</h2></a>
            </div>
            <div id="menu-item-CJ">
                <a href=""><h2>Create Job</h2></a>
            </div>
            <div id="menu-item-JS">
                <a href=""><h2>Availible Swaps</h2></a>
            </div>
            <div id="menu-item-JI">
                <a href=""><h2>Completed Jobs</h2></a>
            </div>
        </div>
    </div>

    <div id="jobDashboard" style="display: block;">
        <h2>Job Dashboard</h2>
        <div id="jobDashboardContent">
        
        <?php

        while ( $avtechts = $result->fetch_assoc()):?>
            <div id="dashboardJob" class="dashboardJobStyle">
                <div class="serviceBoxStyle">
                    <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                </div>
                <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                <h2 id="dateCreated" class="dateCreatedStyle">Date created:<?= $avtechts['creationDate']?></h2>
                <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                <h2 id="sI" class="sIStyle">Service Information:</h2>
                <div class="serviceBox2Style">
                    <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                </div>
                    
                <div>
                
                </div>
            </div>
        <?php endwhile;?>
            <div class="listEnd">
                <h2 class="listEndText">End of Tickets</h2>
            </div>
        </div>
    </div>

    <script>
        //if priority = green{set ticket header to green}
    </script>

    <div id="createJob">
        <div id="jobForm">
            <div id="main_body">
                <div id="form_container">
                    <form id="create_job" class="appnitro" action="insertreceptionist.php" method="post">
                        <div class="form_description">
                </div>						
                <ul >
                
            <li id="li_6" >
            <label class="description" for="element_6">Job Number </label>
            <div>
                <input id="element_6" name="jobNumber" class="element text medium" type="text" maxlength="9" value=""/> 
            </li>		<li id="li_1" >
            <label class="description" for="element_1">Site Name </label>
            <div>
                <input id="element_1" name="siteName" class="element text medium" type="text" maxlength="255" value=""/> 
            </li>		<li id="li_3" >
            <label class="description" for="element_3">Site Manager </label>
            <span>
                <input id="element_3_1" name= "firstName" class="element text" maxlength="255" size="8" value=""/>
                <label>First</label>
            </span>
            <span>
                <input id="element_3_2" name= "lastName" class="element text" maxlength="255" size="14" value=""/>
                <label>Last</label>
            </span>
            </li>		<li id="li_5" >
            <label class="description" for="element_5">Site Manager Phone Number </label>
            <span>
                <input id="element_5_1" name="phoneNumber" class="element text" size="20" maxlength="11" value="" type="text">
                <label for="element_5_1">#No</label>
            </span>
            </li>		<li id="li_4" >
            <label class="description" for="element_4">Address </label>
            
            <div>
                <input id="element_4_1" name="streetAddress" class="element text large" value="" type="text">
                <label for="element_4_1">Street Address</label>
            </div>
        
            <div>
                <input id="element_4_2" name="linetwoAddress" class="element text large" value="" type="text">
                <label for="element_4_2">Address Line 2</label>
            </div>
        
            <div class="left">
                <input id="element_4_3" name="city" class="element text medium" value="" type="text">
                <label for="element_4_3">City</label>
            </div>
        
            <div class="right">
                <input id="element_4_4" name="county" class="element text medium" value="" type="text">
                <label for="element_4_4">County</label>
            </div>
        
            <div class="left">
                <input id="element_4_5" name="postcode" class="element text medium" maxlength="15" value="" type="text">
                <label for="element_4_5">Post Code</label>
            </div>
            </li>		<li id="li_2" >
            <label class="description" for="element_2">Service Call Information </label>
            <div>
                <textarea id="element_2" name="serviceInfo" class="element textarea medium"></textarea> 
            </li>		<li id="li_8" >
            <label class="description" for="element_8">Priority</label>
                <input id="element_8_1" name="priority" class="element radio" type="radio" value="ASAP" />
                <label class="choice" for="priorityASAP">ASAP</label>
                <input id="element_8_2" name="priority" class="element radio" type="radio" value="Needs Adressing" />
                <label class="choice" for="priorityNA">Needs Adressing</label>
                <input id="element_8_3" name="priority" class="element radio" type="radio" value="Small Issue" />
                <label class="choice" for="prioritySI">Small Issue</label>
            </li>
                
                        <li class="buttons">
                    <input type="hidden" name="form_id" value="95546" />
                    
                    <input id="saveForm" class="button_text" type="submit" name="submit" value="Create Job" />
            </li>
                </ul>
            </form>
	</div>
	    <img id="bottom" src="/form/bottom.png" alt="">
    </div>
    </div>
    </div>

    <div id="jobSwaps">
    <h2>Availible Swaps</h2>
        <?php
            while ( $avtechts = $jobSwaps->fetch_assoc()):?>
                <div id="completedJobsStyle" class="dashboardJobStyle">
                    <div class="serviceBoxStyle">
                        <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                    </div>
                    <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                    <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                    <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                    <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                    
                    <h2 id="sI" class="sIStyle">Service Information:</h2>
                    <div class="serviceBox2Style">
                        <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                    </div>
                    <div>
                    <h2 id="previousTime" class="dateCompletedStyle">Swap From: <?= $avtechts['timetableSlot']?></h2>
                    </div>
                    
                </div>
            <?php endwhile;?>
                <div class="listEnd">
                    <h2 class="listEndText">End of Availible Swaps</h2>
                </div>
            </div>
        </div>
    </div>

    <div id="completedJobs">
    <h2>Completed Jobs</h2>
        <?php
            while ( $avtechts = $resultCompletedJobs->fetch_assoc()):?>
                <div id="completedJobsStyle" class="dashboardJobStyle">
                    <div class="serviceBoxStyle">
                        <h2 class="jobNumberStyle">Ticket No#:<?= $avtechts['jobNumber']?></h2>
                    </div>
                    <h1 id="siteName" class="siteNameStyle"><?= $avtechts['siteName']?></h1>
                    <h2 id="managerName" class="managerNameStyle">Manager:<?= $avtechts['firstName']?> <?= $avtechts['lastName']?></h2>
                    <h2 id="phoneNo" class="phoneNoStyle">Phone No#:<?= $avtechts['phoneNumber']?></h2>
                    <h2 id="siteAddress" class="siteAddressStyle">Site Address:<?= $avtechts['streetAddress']?> <?= $avtechts['linetwoAddress']?> <?= $avtechts['city']?> <?= $avtechts['county']?> <?= $avtechts['postcode']?></h2>
                    
                    <h2 id="sI" class="sIStyle">Service Information:</h2>
                    <div class="serviceBox2Style">
                        <h2 id="serviceInfo" class="serviceInfoStyle"><?= $avtechts['serviceInfo']?></h2>
                    </div>
                    <h2 id="dateCompleted" class="dateCompletedStyle">Date Completed: <?= $avtechts['completedDate']?></h2>
                </div>
            <?php endwhile;?>
                <div class="listEnd">
                    <h2 class="listEndText">End of Completed Tickets</h2>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        document.getElementById("menu-item-JD").onclick = function() {
            document.getElementById("jobDashboard").style.display = "block";
            document.getElementById("createJob").style.display = "none";
            document.getElementById("completedJobs").style.display = "none";
            document.getElementById("jobSwaps").style.display = "none";
            event.preventDefault();
        }

        document.getElementById("menu-item-CJ").onclick = function() {
            document.getElementById("createJob").style.display = "block";
            document.getElementById("jobDashboard").style.display = "none";
            document.getElementById("completedJobs").style.display = "none";
            document.getElementById("jobSwaps").style.display = "none";
            event.preventDefault();
        }

        document.getElementById("menu-item-JI").onclick = function() {
            document.getElementById("completedJobs").style.display = "block";
            document.getElementById("jobDashboard").style.display = "none";
            document.getElementById("createJob").style.display = "none";
            document.getElementById("jobSwaps").style.display = "none";
            event.preventDefault();
        }

        document.getElementById("menu-item-JS").onclick = function() {
            document.getElementById("jobSwaps").style.display = "block";
            document.getElementById("completedJobs").style.display = "none";
            document.getElementById("createJob").style.display = "none";
            document.getElementById("jobDashboard").style.display = "none";
            event.preventDefault();
        }
        </script>
</body>