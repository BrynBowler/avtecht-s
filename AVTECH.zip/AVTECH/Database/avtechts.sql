-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Mar 31, 2020 at 05:17 PM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `avtechts`
--

-- --------------------------------------------------------

--
-- Table structure for table `avtechts`
--

DROP TABLE IF EXISTS `avtechts`;
CREATE TABLE IF NOT EXISTS `avtechts` (
  `jobNumber` int(11) NOT NULL,
  `siteName` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `phoneNumber` int(11) DEFAULT NULL,
  `firstName` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `lastName` varchar(20) DEFAULT NULL,
  `streetAddress` varchar(50) DEFAULT NULL,
  `linetwoAddress` varchar(50) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `county` varchar(40) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `serviceInfo` varchar(5000) DEFAULT NULL,
  `priority` varchar(12) DEFAULT NULL,
  `creationDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`jobNumber`)
) ENGINE=MyISAM AUTO_INCREMENT=2147483648 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `avtechts`
--

INSERT INTO `avtechts` (`jobNumber`, `siteName`, `phoneNumber`, `firstName`, `lastName`, `streetAddress`, `linetwoAddress`, `city`, `county`, `postcode`, `serviceInfo`, `priority`, `creationDate`) VALUES
(2147483647, 'The Old Workshop', 2147483647, 'Jamie', 'Dean', '27 Down Street', '', 'Leeds', 'Yorkshire', 'S1 4TU', 'Jukebox Needs Installing', 'Needs Adress', '2020-03-31 18:06:11'),
(123718237, 'The Greenish Room', 2147483647, 'Sarah', 'Jacobs', '21 Cantor Lane', '', 'Chesterfield', 'Derbyshire', 'S1 47R', 'Karaoke Books need Replacing.', 'Small Issue', '2020-03-31 18:11:24'),
(712389719, 'The Old Lion', 2147483647, 'Lucy', 'Jones', '25 Newport Road', '', 'Sheffield', 'Yorkshire', 'S1 9UU', 'Speakers not producing sound, please investigate.', 'Needs Adress', '2020-03-31 18:11:59'),
(636127381, 'The Red Room', 2147483647, 'James', 'Allister', '12 Landown Lane', '', 'Chesterfield', 'Derbyshire', 'S1 47P', 'New Jukebox Installation Required.', 'ASAP', '2020-03-31 18:12:43'),
(387091237, 'The Tram Shed', 2147483647, 'Sarah', 'Bower', '27 Down Street', '', 'Leeds', 'Yorkshire', 'S1 4TU', 'HDMI required for Bingo.', 'Needs Adress', '2020-03-31 18:13:34');

-- --------------------------------------------------------

--
-- Table structure for table `completedjobs`
--

DROP TABLE IF EXISTS `completedjobs`;
CREATE TABLE IF NOT EXISTS `completedjobs` (
  `jobNumber` int(11) NOT NULL,
  `siteName` varchar(40) NOT NULL,
  `phoneNumber` int(11) DEFAULT NULL,
  `firstName` varchar(40) NOT NULL,
  `lastName` varchar(20) DEFAULT NULL,
  `streetAddress` varchar(50) DEFAULT NULL,
  `linetwoAddress` varchar(50) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `county` varchar(40) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `serviceInfo` varchar(5000) DEFAULT NULL,
  `jobDate` varchar(10) DEFAULT NULL,
  `priority` varchar(12) DEFAULT NULL,
  `completedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`jobNumber`)
) ENGINE=MyISAM AUTO_INCREMENT=3748933 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `e1timetable`
--

DROP TABLE IF EXISTS `e1timetable`;
CREATE TABLE IF NOT EXISTS `e1timetable` (
  `jobNumber` int(11) NOT NULL,
  `siteName` varchar(40) NOT NULL,
  `phoneNumber` int(11) DEFAULT NULL,
  `firstName` varchar(40) NOT NULL,
  `lastName` varchar(20) DEFAULT NULL,
  `streetAddress` varchar(50) DEFAULT NULL,
  `linetwoAddress` varchar(50) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `county` varchar(40) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `serviceInfo` varchar(5000) DEFAULT NULL,
  `jobDate` varchar(10) DEFAULT NULL,
  `priority` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `timetableSlot` varchar(20) NOT NULL,
  PRIMARY KEY (`jobNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `e2timetable`
--

DROP TABLE IF EXISTS `e2timetable`;
CREATE TABLE IF NOT EXISTS `e2timetable` (
  `jobNumber` int(11) NOT NULL,
  `siteName` varchar(40) NOT NULL,
  `phoneNumber` int(11) DEFAULT NULL,
  `firstName` varchar(40) NOT NULL,
  `lastName` varchar(20) DEFAULT NULL,
  `streetAddress` varchar(50) DEFAULT NULL,
  `linetwoAddress` varchar(50) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `county` varchar(40) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `serviceInfo` varchar(5000) DEFAULT NULL,
  `jobDate` varchar(10) DEFAULT NULL,
  `priority` varchar(12) DEFAULT NULL,
  `timetableSlot` varchar(20) NOT NULL,
  PRIMARY KEY (`jobNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `e3timetable`
--

DROP TABLE IF EXISTS `e3timetable`;
CREATE TABLE IF NOT EXISTS `e3timetable` (
  `jobNumber` int(11) NOT NULL,
  `siteName` varchar(40) NOT NULL,
  `phoneNumber` int(11) DEFAULT NULL,
  `firstName` varchar(40) NOT NULL,
  `lastName` varchar(20) DEFAULT NULL,
  `streetAddress` varchar(50) DEFAULT NULL,
  `linetwoAddress` varchar(50) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `county` varchar(40) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `serviceInfo` varchar(5000) DEFAULT NULL,
  `jobDate` varchar(10) DEFAULT NULL,
  `priority` varchar(12) DEFAULT NULL,
  `timetableSlot` varchar(20) NOT NULL,
  PRIMARY KEY (`jobNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobswaps`
--

DROP TABLE IF EXISTS `jobswaps`;
CREATE TABLE IF NOT EXISTS `jobswaps` (
  `jobNumber` int(11) NOT NULL,
  `siteName` varchar(40) NOT NULL,
  `phoneNumber` int(11) DEFAULT NULL,
  `firstName` varchar(40) NOT NULL,
  `lastName` varchar(20) DEFAULT NULL,
  `streetAddress` varchar(50) DEFAULT NULL,
  `linetwoAddress` varchar(50) DEFAULT NULL,
  `city` varchar(40) DEFAULT NULL,
  `county` varchar(40) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `serviceInfo` varchar(5000) DEFAULT NULL,
  `jobDate` varchar(10) DEFAULT NULL,
  `priority` varchar(12) DEFAULT NULL,
  `timetableSlot` varchar(20) NOT NULL,
  PRIMARY KEY (`jobNumber`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`) VALUES
('Brad', 'password1'),
('Dan', 'password2'),
('Neil', 'password3'),
('Cheryl', 'password4'),
('Garry', 'password5');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
